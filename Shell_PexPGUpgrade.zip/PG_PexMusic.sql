--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1
-- Dumped by pg_dump version 13.2

-- Started on 2022-11-22 19:03:56

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3158 (class 1262 OID 70633)
-- Name: PexMusic; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "PexMusic" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';

CREATE ROLE "PexSuperUser" WITH
  LOGIN
  NOSUPERUSER
  INHERIT
  NOCREATEDB
  NOCREATEROLE
  NOREPLICATION;
  

alter user PexSuperUser with encrypted password 'temp123';
grant all privileges on database PexMusic  to PexSuperUser ;


ALTER DATABASE "PexMusic" OWNER TO PexSuperUser;

\connect "PexMusic"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 200 (class 1259 OID 70638)
-- Name: Album; Type: TABLE; Schema: public; Owner: PexSuperUser
--

CREATE TABLE public."Album" (
    "Album_ID" numeric NOT NULL,
    "Album_Name" text,
    "Track_ID" numeric
);


ALTER TABLE public."Album" OWNER TO "PexSuperUser";

--
-- TOC entry 205 (class 1259 OID 70678)
-- Name: Catalog; Type: TABLE; Schema: public; Owner: PexSuperUser
--

CREATE TABLE public."Catalog" (
    "Track_ID" numeric,
    "RightHolder_ID" numeric,
    "Album_ID" numeric,
    "Due_Date" date,
    "ID" numeric NOT NULL
);


ALTER TABLE public."Catalog" OWNER TO "PexSuperUser";

--
-- TOC entry 202 (class 1259 OID 70654)
-- Name: RightHolders; Type: TABLE; Schema: public; Owner: PexSuperUser
--

CREATE TABLE public."RightHolders" (
    "RightHolder_ID" numeric NOT NULL,
    "RightHolder_Name" text
);


ALTER TABLE public."RightHolders" OWNER TO "PexSuperUser";

--
-- TOC entry 201 (class 1259 OID 70646)
-- Name: Tracks; Type: TABLE; Schema: public; Owner: PexSuperUser
--

CREATE TABLE public."Tracks" (
    "Track_ID" numeric NOT NULL,
    "Track_Name" text
);


ALTER TABLE public."Tracks" OWNER TO "PexSuperUser";

--
-- TOC entry 203 (class 1259 OID 70662)
-- Name: Users; Type: TABLE; Schema: public; Owner: PexSuperUser
--

CREATE TABLE public."Users" (
    " User_ID" numeric NOT NULL,
    "User_Name" text,
    "Status" text,
    "Passwd" text
);


ALTER TABLE public."Users" OWNER TO "PexSuperUser";

--
-- TOC entry 204 (class 1259 OID 70670)
-- Name: Users_RigthHolder; Type: TABLE; Schema: public; Owner: PexSuperUser
--

CREATE TABLE public."Users_RigthHolder" (
    "User_ID" numeric NOT NULL,
    "RightHolder_ID" numeric NOT NULL,
    "Due_Date" date
);


ALTER TABLE public."Users_RigthHolder" OWNER TO "PexSuperUser";

--
-- TOC entry 3014 (class 2606 OID 70645)
-- Name: Album Album_pkey; Type: CONSTRAINT; Schema: public; Owner: PexSuperUser
--

ALTER TABLE ONLY public."Album"
    ADD CONSTRAINT "Album_pkey" PRIMARY KEY ("Album_ID");


--
-- TOC entry 3022 (class 2606 OID 70685)
-- Name: Catalog Catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: PexSuperUser
--

ALTER TABLE ONLY public."Catalog"
    ADD CONSTRAINT "Catalog_pkey" PRIMARY KEY ("ID");


--
-- TOC entry 3018 (class 2606 OID 70661)
-- Name: RightHolders RightHolders_pkey; Type: CONSTRAINT; Schema: public; Owner: PexSuperUser
--

ALTER TABLE ONLY public."RightHolders"
    ADD CONSTRAINT "RightHolders_pkey" PRIMARY KEY ("RightHolder_ID");


--
-- TOC entry 3016 (class 2606 OID 70653)
-- Name: Tracks Tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: PexSuperUser
--

ALTER TABLE ONLY public."Tracks"
    ADD CONSTRAINT "Tracks_pkey" PRIMARY KEY ("Track_ID");


--
-- TOC entry 3020 (class 2606 OID 70669)
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: PexSuperUser
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (" User_ID");


--
-- TOC entry 3159 (class 0 OID 0)
-- Dependencies: 3158
-- Name: DATABASE "PexMusic"; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE "PexMusic" TO "PexSuperUser";
GRANT CONNECT ON DATABASE "PexMusic" TO "PexROUser";
GRANT CONNECT ON DATABASE "PexMusic" TO "PexWriteUser";


--
-- TOC entry 1735 (class 826 OID 70637)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

CREATE ROLE "PexWriteUser" WITH
  LOGIN
  NOSUPERUSER
  INHERIT
  NOCREATEDB
  NOCREATEROLE
  NOREPLICATION;

CREATE ROLE "PexROUser" WITH
  LOGIN
  NOSUPERUSER
  INHERIT
  NOCREATEDB
  NOCREATEROLE
  NOREPLICATION;


alter user PexWriteUser with encrypted password 'temp123';
grant SELECT, INSERT, UPDATE, DELETE  on database PexMusic  to PexWriteUser ;

alter user PexROUser with encrypted password 'temp123';
grant SELECT ON ALL TABLES on database PexMusic  to PexROUser ;


ALTER DEFAULT PRIVILEGES FOR ROLE PexSuperUser GRANT ALL ON TABLES  TO "PexSuperUser";
ALTER DEFAULT PRIVILEGES FOR ROLE PexSuperUser GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES  TO "PexWriteUser";
ALTER DEFAULT PRIVILEGES FOR ROLE PexSuperUser GRANT SELECT ON TABLES  TO "PexROUser";


-- Completed on 2022-11-22 19:04:01

--
-- PostgreSQL database dump complete
--

